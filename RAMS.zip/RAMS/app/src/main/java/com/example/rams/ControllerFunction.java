package com.example.rams;

import androidx.annotation.NonNull;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ControllerFunction {
    public static void retrieveEmp(){
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference().child("Employee");

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snap: snapshot.getChildren()) {
                    if(snap.exists()) {
                        ObjectEmployee.addEmp(snap.getKey().toString()); // Employee ID
                        ObjectEmployee.addEmp(snap.child("Username").getValue().toString());
                        ObjectEmployee.addEmp(snap.child("Password").getValue().toString());
                        ObjectEmployee.addEmp(snap.child("FirstName").getValue().toString());
                        ObjectEmployee.addEmp(snap.child("MiddleName").getValue().toString());
                        ObjectEmployee.addEmp(snap.child("LastName").getValue().toString());
                        ObjectEmployee.addEmp(snap.child("DefaultLocation").getValue().toString());
                        ObjectEmployee.addEmp(snap.child("DefLat").getValue().toString());
                        ObjectEmployee.addEmp(snap.child("DefLon").getValue().toString());
                        ObjectEmployee.addEmp(snap.child("AssignedLocation").getValue().toString());
                        ObjectEmployee.addEmp(snap.child("AssLat").getValue().toString());
                        ObjectEmployee.addEmp(snap.child("AssLon").getValue().toString());
                    } else {
                        ref.removeEventListener(this);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public static void retrieveAttendance(){
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference().child("Attendance");

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snap: snapshot.getChildren()) {
                    if(snap.exists()) {
                        for(DataSnapshot s: snap.getChildren()){
                            ObjectAttendance.addAtt(snap.getKey().toString()); // Date
                            ObjectAttendance.addAtt(s.getKey().toString()); // Emp ID
                            ObjectAttendance.addAtt(s.child("TimeIN").getValue().toString());
                            ObjectAttendance.addAtt(s.child("LocationIN").getValue().toString());
                            ObjectAttendance.addAtt(s.child("TimeOUT").getValue().toString());
                            ObjectAttendance.addAtt(s.child("LocationOUT").getValue().toString());
                            ObjectAttendance.addAtt(s.child("Status").getValue().toString());
                        }
                    } else {
                        ref.removeEventListener(this);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public static void savePass(String password){
        String pass = encryptStr(password);

        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference().child("Employee");

        // Update Database
        ref.child(ObjectEmployee.getEmpID())
                .child("Password")
                .setValue(pass, null);

        // Update Local Variable
        for(int i = 1; i < ObjectEmployee.getSize(); i++){
            if(ObjectEmployee.getEmp(i - 1).equals(ObjectEmployee.getEmpID())){
                ObjectEmployee.editEmp(i + 1, pass);
            } else{
                i += 11;
            }
        }
    }

    public static String encryptStr(String str){
        MessageDigest m;
        try {
            m = MessageDigest.getInstance("MD5");
            m.update(str.getBytes());
            byte[] bytes = m.digest();
            StringBuilder s = new StringBuilder();
            for(int i = 0; i < bytes.length; i++) {
                s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            str = s.toString();
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return str;
    }

    public static void logIN(double currLatitude, double currLongitude){
        // Get Date
        Date c = Calendar.getInstance().getTime();

        SimpleDateFormat date = new SimpleDateFormat("MM dd yyyy", Locale.getDefault());
        String formattedDate = date.format(c);

        // Get Time
        SimpleDateFormat time = new SimpleDateFormat("HH:mm", Locale.getDefault());
        String formattedTime = time.format(c);

        // Get the Distance from the Location
        double dist1 = distance(Double.parseDouble(String.valueOf(currLatitude)),
                Double.parseDouble(ObjectEmployee.getDefLat()),
                Double.parseDouble(String.valueOf(currLongitude)),
                Double.parseDouble(ObjectEmployee.getDefLon()),
                0, 0);

        double dist2 = distance(Double.parseDouble(String.valueOf(currLatitude)),
                Double.parseDouble(ObjectEmployee.getAssLat()),
                Double.parseDouble(String.valueOf(currLongitude)),
                Double.parseDouble(ObjectEmployee.getAssLon()),
                0, 0);

        // Save Log to Database
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference().child("Attendance").
                child(formattedDate).
                child(ObjectEmployee.getEmpID());

        ref.child("TimeIN").setValue(formattedTime);
        ref.child("Status").setValue("NA");
        if(dist1 < 100 || dist2 < 100){
            ref.child("LocationIN").setValue("True");
            // Save to Local
            ObjectAttendance.setLocationIN("True");
        } else{
            ref.child("LocationIN").setValue("False");
            // Save to Local
            ObjectAttendance.setLocationIN("False");
        }
        // Dummy Time OUT
        ref.child("TimeOUT").setValue("");
        ref.child("LocationOUT").setValue("");

        // Save to Local
        ObjectAttendance.setDate(formattedDate);
        ObjectAttendance.setTimeIN(formattedTime);
        ObjectAttendance.setId(ObjectEmployee.getEmpID());
        ObjectAttendance.setStatus("NA");
    }

    public static void logOUT(double currLatitude, double currLongitude) {
        // Get Date
        Date c = Calendar.getInstance().getTime();

        SimpleDateFormat date = new SimpleDateFormat("MM dd yyyy", Locale.getDefault());
        String formattedDate = date.format(c);

        // Get Time
        SimpleDateFormat time = new SimpleDateFormat("HH:mm", Locale.getDefault());
        String formattedTime = time.format(c);

        // Get the Distance from the Location
        double dist1 = distance(Double.parseDouble(String.valueOf(currLatitude)),
                Double.parseDouble(ObjectEmployee.getDefLat()),
                Double.parseDouble(String.valueOf(currLongitude)),
                Double.parseDouble(ObjectEmployee.getDefLon()),
                0, 0);

        double dist2 = distance(Double.parseDouble(String.valueOf(currLatitude)),
                Double.parseDouble(ObjectEmployee.getAssLat()),
                Double.parseDouble(String.valueOf(currLongitude)),
                Double.parseDouble(ObjectEmployee.getAssLon()),
                0, 0);

        // Save Log to Database
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference().child("Attendance").
                child(formattedDate).
                child(ObjectEmployee.getEmpID());

        String stat = "";
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
        Date timeOUT = null, timeIN = null;
        try{
            timeOUT = formatter.parse(formattedTime);
            timeIN = formatter.parse(ObjectAttendance.getTimeIN());
        } catch(ParseException pe){
            pe.printStackTrace();
        }
        long diff = timeOUT.getTime() - timeIN.getTime();
        long diffHours = diff / (60 * 60 * 1000);

        if(diffHours < 8){
            stat = "Late";
        } else{
            stat = "Present";
        }

        ref.child("TimeOUT").setValue(formattedTime);
        ref.child("Status").setValue(stat);
        if(dist1 < 100 || dist2 < 100){
            ref.child("LocationOUT").setValue("True");
            // Save to Local
            ObjectAttendance.setLocationOUT("True");
        } else{
            ref.child("LocationOUT").setValue("False");
            // Save to Local
            ObjectAttendance.setLocationOUT("False");
        }
        // Save to Local
        ObjectAttendance.setDate(formattedDate);
        ObjectAttendance.setTimeOUT(formattedTime);
        ObjectAttendance.setId(ObjectEmployee.getEmpID());
        ObjectAttendance.setStatus(stat);

        // Save to Local List
        ObjectAttendance.addAtt(ObjectAttendance.getDate());
        ObjectAttendance.addAtt(ObjectAttendance.getId());
        ObjectAttendance.addAtt(ObjectAttendance.getTimeIN());
        ObjectAttendance.addAtt(ObjectAttendance.getLocationIN());
        ObjectAttendance.addAtt(ObjectAttendance.getTimeOUT());
        ObjectAttendance.addAtt(ObjectAttendance.getLocationOUT());
        ObjectAttendance.addAtt(ObjectAttendance.getStatus());
    }

    public static double distance(double lat1, double lat2, double lon1,
                                  double lon2, double el1, double el2) {
        // Haversine Method in Calculating the Distance in Meters
        final int R = 6371; // Radius of the earth

        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * c * 1000; // convert to meters

        double height = el1 - el2;

        distance = Math.pow(distance, 2) + Math.pow(height, 2);

        return Math.sqrt(distance);
    }
}
