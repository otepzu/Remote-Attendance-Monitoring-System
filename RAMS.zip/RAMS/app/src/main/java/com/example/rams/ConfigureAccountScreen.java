package com.example.rams;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class ConfigureAccountScreen extends AppCompatActivity {

    EditText inpNewPass, inpConfirmPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configure_account_screen);

        inpNewPass = (EditText) findViewById(R.id.inpNewPass);
        inpConfirmPass = (EditText) findViewById(R.id.inpConfirmPass);
    }

    public void btnSave(View view){
        String newPass = inpNewPass.getText().toString();
        String confirmPass = inpConfirmPass.getText().toString();

        if(newPass.equals(confirmPass)){
            ControllerFunction.savePass(newPass);

            Intent intent = new Intent(ConfigureAccountScreen.this, AccountSettingScreen.class);
            startActivity(intent);
            finish();
        }
    }

    public void btnBack(View view){
        Intent intent = new Intent(ConfigureAccountScreen.this, AccountSettingScreen.class);
        startActivity(intent);
        finish();
    }
}