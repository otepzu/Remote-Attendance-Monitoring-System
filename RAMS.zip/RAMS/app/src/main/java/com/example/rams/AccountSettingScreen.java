package com.example.rams;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AccountSettingScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_setting_screen);

        TextView lblName = (TextView) findViewById(R.id.lblName);
        TextView lblUsername = (TextView) findViewById(R.id.lblUsername);
        TextView lblID = (TextView) findViewById(R.id.lblID);

        lblName.setText(ObjectEmployee.getFirstName() + " " + ObjectEmployee.getLastName());
        lblUsername.setText("Username: " + ObjectEmployee.getUsername());
        lblID.setText("Employee ID: " + ObjectEmployee.getEmpID());
    }

    public void btnBack(View v){
        Intent intent = new Intent(AccountSettingScreen.this, DashboardScreen.class);
        startActivity(intent);
        finish();
    }

    public void btnEdit(View v){
        Intent intent = new Intent(AccountSettingScreen.this, ConfigureAccountScreen.class);
        startActivity(intent);
        finish();
    }

    public void btnLogout(View view){
        ObjectAttendance.setDate("");
        ObjectAttendance.setId("");
        ObjectAttendance.setTimeIN("");
        ObjectAttendance.setLocationIN("");
        ObjectAttendance.setTimeOUT("");
        ObjectAttendance.setLocationOUT("");
        ObjectAttendance.setStatus("");

        Intent intent = new Intent(AccountSettingScreen.this, LoginScreen.class);
        startActivity(intent);
        finish();
    }
}