package com.example.rams;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;

public class ViewAttendanceScreen extends AppCompatActivity {

    TextView tvPresent, tvAbsent, tvLate;
    PieChart pieChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_attendance_screen);

        tvPresent = findViewById(R.id.tvPresent);
        tvAbsent = findViewById(R.id.tvAbsent);
        tvLate = findViewById(R.id.tvLate);
        pieChart = findViewById(R.id.pieChart);

        setData();
    }

    private void setData(){
        int present = 0, absent = 0, late = 0;

        for(int i = 0; i < ObjectAttendance.getSize(); i++){
            System.out.println(ObjectAttendance.getAtt(i));
        }

        for(int i = 0; i < ObjectAttendance.getSize(); i++){
            if(ObjectAttendance.getAtt(i + 1).equals(ObjectEmployee.getEmpID())){
                switch(ObjectAttendance.getAtt(i + 6)){
                    case "Present":
                        present++;
                        break;
                    case "Absent":
                        absent++;
                        break;
                    case "Late":
                        late++;
                        break;
                }
            }
            i += 6;
        }

        tvPresent.setText(Integer.toString(present));
        tvAbsent.setText(Integer.toString(absent));
        tvLate.setText(Integer.toString(late));

        // Set the data and color to the pie chart
        pieChart.addPieSlice(
                new PieModel(
                        "Present",
                        Integer.parseInt(tvPresent.getText().toString()),
                        Color.parseColor("#33ff33")));
        pieChart.addPieSlice(
                new PieModel(
                        "Absent",
                        Integer.parseInt(tvAbsent.getText().toString()),
                        Color.parseColor("#ff0000")));
        pieChart.addPieSlice(
                new PieModel(
                        "Late",
                        Integer.parseInt(tvLate.getText().toString()),
                        Color.parseColor("#ffff00")));

        pieChart.startAnimation();
    }

    public void btnBack(View v){
        Intent intent = new Intent(ViewAttendanceScreen.this, DashboardScreen.class);
        startActivity(intent);
        finish();
    }
}