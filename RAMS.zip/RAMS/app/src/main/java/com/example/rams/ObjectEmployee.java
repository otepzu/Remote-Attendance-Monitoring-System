package com.example.rams;

import java.util.ArrayList;

public class ObjectEmployee {
    private static String empID;
    private static String username;
    private static String password;
    private static String firstName;
    private static String middleName;
    private static String lastName;
    private static String defaultLocation;
    private static String defLat;
    private static String defLon;
    private static String assignedLocation;
    private static String assLat;
    private static String assLon;
    private static ArrayList<String> empList = new ArrayList<>();

    // Listed Employees

    public static void addEmp(String emp){
        ObjectEmployee.empList.add(emp);
    }

    public static String getEmp(int i){
        return ObjectEmployee.empList.get(i);
    }

    public static int getSize(){
        return ObjectEmployee.empList.size();
    }

    public static void editEmp(int i, String emp){
        ObjectEmployee.empList.set(i, emp);
    }

    // Single Value

    public static String getDefLat() {
        return defLat;
    }

    public static void setDefLat(String defLat) {
        ObjectEmployee.defLat = defLat;
    }

    public static String getDefLon() {
        return defLon;
    }

    public static void setDefLon(String defLon) {
        ObjectEmployee.defLon = defLon;
    }

    public static String getAssLat() {
        return assLat;
    }

    public static void setAssLat(String assLat) {
        ObjectEmployee.assLat = assLat;
    }

    public static String getAssLon() {
        return assLon;
    }

    public static void setAssLon(String assLon) {
        ObjectEmployee.assLon = assLon;
    }

    public static String getEmpID() {
        return empID;
    }

    public static void setEmpID(String empID) {
        ObjectEmployee.empID = empID;
    }

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        ObjectEmployee.username = username;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        ObjectEmployee.password = password;
    }

    public static String getFirstName() {
        return firstName;
    }

    public static void setFirstName(String firstName) {
        ObjectEmployee.firstName = firstName;
    }

    public static String getMiddleName() {
        return middleName;
    }

    public static void setMiddleName(String middleName) {
        ObjectEmployee.middleName = middleName;
    }

    public static String getLastName() {
        return lastName;
    }

    public static void setLastName(String lastName) {
        ObjectEmployee.lastName = lastName;
    }

    public static String getDefaultLocation() {
        return defaultLocation;
    }

    public static void setDefaultLocation(String defaultLocation) {
        ObjectEmployee.defaultLocation = defaultLocation;
    }

    public static String getAssignedLocation() {
        return assignedLocation;
    }

    public static void setAssignedLocation(String assignedLocation) {
        ObjectEmployee.assignedLocation = assignedLocation;
    }
}
