package com.example.rams;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.ParseException;

public class AttendanceScreen extends AppCompatActivity {
    private GpsTracker gpsTracker;
    double latitude;
    double longitude;

    Button btnTimeIN, btnTimeOUT;
    EditText noInpTimeIN, noInpDateIN, noInpTimeOUT, noInpDateOUT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_screen);

        btnTimeIN = (Button) findViewById(R.id.btnTimeIN);
        btnTimeOUT = (Button) findViewById(R.id.btnTimeOUT);
        noInpTimeIN = (EditText) findViewById(R.id.noInpTimeIN);
        noInpDateIN = (EditText) findViewById(R.id.noInpDateIN);
        noInpTimeOUT = (EditText) findViewById(R.id.noInpTimeOUT);
        noInpDateOUT = (EditText) findViewById(R.id.noInpDateOUT);

        if(!ObjectAttendance.getTimeIN().equals("") && !ObjectAttendance.getTimeOUT().equals("")){
            btnTimeIN.setEnabled(false);
            btnTimeOUT.setEnabled(false);

            noInpTimeIN.setText(ObjectAttendance.getTimeIN());
            noInpDateIN.setText(ObjectAttendance.getDate());
            noInpTimeOUT.setText(ObjectAttendance.getTimeOUT());
            noInpDateOUT.setText(ObjectAttendance.getDate());
        } else if(!ObjectAttendance.getTimeIN().equals("")){
            btnTimeIN.setEnabled(false);

            noInpTimeIN.setText(ObjectAttendance.getTimeIN());
            noInpDateIN.setText(ObjectAttendance.getDate());
        } else{
            btnTimeOUT.setEnabled(false);
        }

        try {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 101);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void btnIn(View view){
        gpsTracker = new GpsTracker(AttendanceScreen.this);
        if(gpsTracker.canGetLocation()){
            latitude = gpsTracker.getLatitude();
            longitude = gpsTracker.getLongitude();
        }else{
            gpsTracker.showSettingsAlert();
        }

        ControllerFunction.logIN(latitude, longitude);

        btnTimeIN.setEnabled(false);
        btnTimeOUT.setEnabled(true);

        noInpTimeIN.setText(ObjectAttendance.getTimeIN());
        noInpDateIN.setText(ObjectAttendance.getDate());
    }

    public void btnOut(View view) {
        gpsTracker = new GpsTracker(AttendanceScreen.this);
        if(gpsTracker.canGetLocation()){
            latitude = gpsTracker.getLatitude();
            longitude = gpsTracker.getLongitude();
        }else{
            gpsTracker.showSettingsAlert();
        }

        ControllerFunction.logOUT(latitude, longitude);

        btnTimeOUT.setEnabled(false);

        noInpTimeOUT.setText(ObjectAttendance.getTimeOUT());
        noInpDateOUT.setText(ObjectAttendance.getDate());
    }

    public void btnBack(View view){
        Intent intent = new Intent(AttendanceScreen.this, DashboardScreen.class);
        startActivity(intent);
        finish();
    }
}