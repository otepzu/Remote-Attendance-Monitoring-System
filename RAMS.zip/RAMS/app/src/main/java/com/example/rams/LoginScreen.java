package com.example.rams;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginScreen extends AppCompatActivity {
    private EditText inpUsername, inpPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        inpUsername = (EditText) findViewById(R.id.inpUsername);
        inpPassword = (EditText) findViewById(R.id.inpPassword);
    }

    public void btnLogin(View view){
        // Getting the Values from EditText
        String username = inpUsername.getText().toString();
        String password = ControllerFunction.encryptStr(inpPassword.getText().toString());

        // Stream all data from the Employee List
        for(int i = 1; i < ObjectEmployee.getSize(); i++){
            // Verification via Username
            if(ObjectEmployee.getEmp(i).equals(username)){
                // Verification Via Password
                if(ObjectEmployee.getEmp(i + 1).equals(password)){
                    // Assign to Object if Matched
                    ObjectEmployee.setEmpID(ObjectEmployee.getEmp(i - 1));
                    ObjectEmployee.setUsername(ObjectEmployee.getEmp(i));
                    ObjectEmployee.setPassword(ObjectEmployee.getEmp(i + 1));
                    ObjectEmployee.setFirstName(ObjectEmployee.getEmp(i + 2));
                    ObjectEmployee.setMiddleName(ObjectEmployee.getEmp(i + 3));
                    ObjectEmployee.setLastName(ObjectEmployee.getEmp(i + 4));
                    ObjectEmployee.setDefaultLocation(ObjectEmployee.getEmp(i + 5));
                    ObjectEmployee.setDefLat(ObjectEmployee.getEmp(i + 6));
                    ObjectEmployee.setDefLon(ObjectEmployee.getEmp(i + 7));
                    ObjectEmployee.setAssignedLocation(ObjectEmployee.getEmp(i + 8));
                    ObjectEmployee.setAssLat(ObjectEmployee.getEmp(i + 9));
                    ObjectEmployee.setAssLon(ObjectEmployee.getEmp(i + 10));

                    Intent intent = new Intent(this, DashboardScreen.class);
                    startActivity(intent);
                    finish();
                }
            } else{
                i += 11;
            }
        }
    }
}