package com.example.rams;

import java.util.ArrayList;

public class ObjectAttendance {
    private static String date;
    private static String id;
    private static String timeIN;
    private static String timeOUT;
    private static String locationIN;
    private static String locationOUT;
    private static String status; // NA - Present - Late - Absent
    private static ArrayList<String> attList = new ArrayList<>();

    // Attendance List

    public static int getSize(){
        return ObjectAttendance.attList.size();
    }

    public static void addAtt(String str){
        ObjectAttendance.attList.add(str);
    }

    public static String getAtt(int i){
        return ObjectAttendance.attList.get(i);
    }

    public static void editAtt(int i, String str){
        ObjectAttendance.attList.set(i, str);
    }

    // Single Value

    public static String getDate() {
        return date;
    }

    public static void setDate(String date) {
        ObjectAttendance.date = date;
    }

    public static String getId() {
        return id;
    }

    public static void setId(String id) {
        ObjectAttendance.id = id;
    }

    public static String getTimeIN() {
        return timeIN;
    }

    public static void setTimeIN(String timeIN) {
        ObjectAttendance.timeIN = timeIN;
    }

    public static String getTimeOUT() {
        return timeOUT;
    }

    public static void setTimeOUT(String timeOUT) {
        ObjectAttendance.timeOUT = timeOUT;
    }

    public static String getLocationIN() {
        return locationIN;
    }

    public static void setLocationIN(String locationIN) {
        ObjectAttendance.locationIN = locationIN;
    }

    public static String getLocationOUT() {
        return locationOUT;
    }

    public static void setLocationOUT(String locationOUT) {
        ObjectAttendance.locationOUT = locationOUT;
    }

    public static String getStatus() {
        return status;
    }

    public static void setStatus(String status) {
        ObjectAttendance.status = status;
    }
}
