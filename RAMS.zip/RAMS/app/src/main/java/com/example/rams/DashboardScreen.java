package com.example.rams;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DashboardScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_screen);

        // Update View
        String prompt = "Welcome, ";
        TextView lblUser = (TextView) findViewById(R.id.lblUser);
        prompt += ObjectEmployee.getFirstName() + " " + ObjectEmployee.getLastName();
        lblUser.setText(prompt);

        // Retrieve Current Attendance
        Date c = Calendar.getInstance().getTime();

        SimpleDateFormat date = new SimpleDateFormat("MM dd yyyy", Locale.getDefault());
        String formattedDate = date.format(c);

        // Initializa
        ObjectAttendance.setDate("");
        ObjectAttendance.setId("");
        ObjectAttendance.setTimeIN("");
        ObjectAttendance.setLocationIN("");
        ObjectAttendance.setTimeOUT("");
        ObjectAttendance.setLocationOUT("");
        ObjectAttendance.setStatus("");
        for(int i = 0; i < ObjectAttendance.getSize(); i++){
            if(ObjectAttendance.getAtt(i).equals(formattedDate) &&
                    ObjectAttendance.getAtt(i + 1).equals(ObjectEmployee.getEmpID())){
                ObjectAttendance.setDate(ObjectAttendance.getAtt(i));
                ObjectAttendance.setId(ObjectAttendance.getAtt(i + 1));
                ObjectAttendance.setTimeIN(ObjectAttendance.getAtt(i + 2));
                ObjectAttendance.setLocationIN(ObjectAttendance.getAtt(i + 3));
                ObjectAttendance.setTimeOUT(ObjectAttendance.getAtt(i + 4));
                ObjectAttendance.setLocationOUT(ObjectAttendance.getAtt(i + 5));
                ObjectAttendance.setStatus(ObjectAttendance.getAtt(i + 6));
            } else{
                i += 6;
            }
        }
    }

    public void btnLog(View view){
        Intent intent = new Intent(DashboardScreen.this, AttendanceScreen.class);
        startActivity(intent);
        finish();
    }

    public void btnSettings(View view) {
        Intent intent = new Intent(DashboardScreen.this, AccountSettingScreen.class);
        startActivity(intent);
        finish();
    }

    public void btnView(View view){
        Intent intent = new Intent(DashboardScreen.this, ViewAttendanceScreen.class);
        startActivity(intent);
        finish();
    }
}